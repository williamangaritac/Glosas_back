package com.Glosas_back;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GlosasBackApplication {

	public static void main(String[] args) {
		SpringApplication.run(GlosasBackApplication.class, args);
	}

}
